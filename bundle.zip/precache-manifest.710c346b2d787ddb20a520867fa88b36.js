self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "389991e8b90865766b8d7303cc62ea6f",
    "url": "./index.html"
  },
  {
    "revision": "36de4ac6389c95d353be",
    "url": "./static/css/2.8337bb56.chunk.css"
  },
  {
    "revision": "28bcf8df13ac351011ed",
    "url": "./static/css/main.981f7211.chunk.css"
  },
  {
    "revision": "36de4ac6389c95d353be",
    "url": "./static/js/2.952b4f2f.chunk.js"
  },
  {
    "revision": "21ced859ea2b2d6b856d461ad6c2afed",
    "url": "./static/js/2.952b4f2f.chunk.js.LICENSE.txt"
  },
  {
    "revision": "28bcf8df13ac351011ed",
    "url": "./static/js/main.b3f9d7ce.chunk.js"
  },
  {
    "revision": "02eb7e5f24a8eb60c357",
    "url": "./static/js/runtime-main.5d409247.js"
  },
  {
    "revision": "4e1ec8403d903dc514271d7328fbdeb3",
    "url": "./static/media/persik.4e1ec840.png"
  }
]);